const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const GOOGLE_SHEET_CSV_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vRaDCGxkQyoqBF6_genJT1KztlWoeY8cNLMlIRSlSKSvRLidz_449ZFzbrO0sCQFf9HGiYdySFa8weC/pub?output=csv';

app.use(cors());

app.get('/csr-data', async (req, res) => {
  try {
    const response = await axios.get(GOOGLE_SHEET_CSV_URL);
    res.header('Content-Type', 'text/csv');
    res.send(response.data);
  } catch (error) {
    res.status(500).send('Failed to fetch CSV');
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`Proxy API running on port ${PORT}`);
});
